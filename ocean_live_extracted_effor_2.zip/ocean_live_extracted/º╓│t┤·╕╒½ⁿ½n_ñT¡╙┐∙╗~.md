# 快速測試指南 - 三個錯誤修復驗證

## 測試前準備

1. **啟動服務器**
   ```powershell
   node server.js
   ```

2. **打開兩個瀏覽器窗口**
   - 窗口A: 主播端
   - 窗口B: 觀眾端

---

## 測試1: 主播設備自動載入 ✅

### 步驟
1. 在窗口A打開: `http://localhost:3000/livestream_platform.html`
2. 登入主播帳號
3. **按 F12 打開開發者工具**

### 預期結果 ✅
**控制台日誌應該出現:**
```
🔍 [loadDevices] 開始載入裝置...
🔍 [loadDevices] DOM 元素檢查: {cameraSelect: true, microphoneSelect: true, audioOutputSelect: true}
📋 初始裝置列表 (X 個): [...]
🏷️ 裝置標籤狀態: 已有標籤
📊 裝置統計: {cameras: X, microphones: X, audioOutputs: X}
📝 開始填充設備選擇器...
📝 [populateDeviceSelect] 開始填充 攝影機: {selectEl: true, deviceCount: X, type: "camera"}
✅ 已添加 X 個攝影機選項
📝 [populateDeviceSelect] 開始填充 麥克風: {selectEl: true, deviceCount: X, type: "microphone"}
✅ 已添加 X 個麥克風選項
📝 [populateDeviceSelect] 開始填充 音訊輸出端: {selectEl: true, deviceCount: X, type: "audioOutput"}
✅ 已添加 X 個音訊輸出端選項
```

**UI 檢查:**
- [ ] 「攝影機」下拉選單顯示設備列表（不是「載入中...」）
- [ ] 「麥克風」下拉選單顯示設備列表（不是「載入中...」）
- [ ] 「音訊輸出」下拉選單顯示設備列表（不是「載入中...」）

### 如果失敗 ❌
檢查控制台是否有以下錯誤:
- `❌ 設備選擇器元素不存在` → HTML 元素 ID 不匹配
- `❌ 瀏覽器不支援裝置列舉` → 瀏覽器版本過舊
- `⚠️ 無法預先取得裝置權限` → 用戶拒絕權限請求

---

## 測試2: 觀眾端邊框特效 🌈

### 步驟
1. 窗口A（主播）點擊「開始直播」
2. 窗口B打開: `http://localhost:3000/viewer.html?broadcaster=[主播ID]`
3. 等待視頻連接
4. **窗口B按 F12 打開開發者工具**
5. 窗口A（主播）選擇「彩虹邊框」特效

### 預期結果 ✅
**窗口B控制台日誌:**
```
收到遠程視頻流 {...}
✅ 添加 live 類別到 stream-video 容器
✅ 視頻元數據已載入
🎨 收到特效更新: rainbowBorder 來自主播: [ID]
🔍 [DEBUG] 視頻容器狀態: {hasLiveClass: true, ...}
✅ 彩虹邊框已應用到容器
```

**UI 檢查:**
- [ ] 觀眾端可以看到主播的視頻
- [ ] 視頻周圍出現彩虹色漸變邊框
- [ ] 邊框有動畫效果（顏色循環變化）

**控制台驗證:**
在窗口B控制台執行:
```javascript
const streamVideo = document.getElementById('streamVideo');
console.log('Has live class:', streamVideo.classList.contains('live'));
console.log('Has rainbow border:', streamVideo.classList.contains('effect-rainbow-border'));
const video = document.getElementById('remoteVideo');
console.log('Video display:', window.getComputedStyle(video).display);
```
應該看到:
```
Has live class: true
Has rainbow border: true
Video display: block
```

### 測試霓虹邊框
1. 窗口A（主播）選擇「霓虹邊框」特效
2. 窗口B應該看到視頻周圍出現霓虹發光效果

---

## 測試3: 觀眾端彩虹濾鏡 🎨

### 步驟
1. 確保測試2已通過（視頻正常顯示）
2. 窗口A（主播）選擇「彩虹濾鏡」特效
3. 觀察窗口B的變化

### 預期結果 ✅
**窗口B控制台日誌:**
```
🎨 收到特效更新: rainbow 來自主播: [ID]
🔍 [DEBUG] 視頻元素狀態: {
  computedDisplay: "block",
  visibility: "visible",
  opacity: "1",
  ...
}
🎨 應用特效: rainbow
✅ 彩虹濾鏡已應用到視頻元素
   - 計算樣式 filter: [應該有值]
   - 計算樣式 animation: [應該有值]
```

**UI 檢查:**
- [ ] 視頻畫面有彩虹色調變化
- [ ] 彩虹色調持續變化（不是靜態的）
- [ ] 色調變化流暢，無閃爍

**控制台驗證:**
在窗口B控制台執行:
```javascript
const video = document.getElementById('remoteVideo');
console.log('Has rainbow filter:', video.classList.contains('effect-rainbow-filter'));
console.log('Filter:', window.getComputedStyle(video).filter);
console.log('Animation:', window.getComputedStyle(video).animation);
```
應該看到:
```
Has rainbow filter: true
Filter: hue-rotate(...) [會變化]
Animation: rainbow-cycle 3s linear infinite [或類似]
```

---

## 快速檢查清單

### 主播端 (窗口A)
- [ ] 頁面載入後立即看到設備列表（不超過 2 秒）
- [ ] 三個設備選擇器都有內容
- [ ] 可以成功開始直播
- [ ] 切換特效時沒有錯誤

### 觀眾端 (窗口B)
- [ ] 可以連接到主播
- [ ] 視頻正常顯示
- [ ] 彩虹邊框正確顯示並有動畫
- [ ] 霓虹邊框正確顯示並有發光效果
- [ ] 彩虹濾鏡正確應用並有動畫

---

## 常見問題

### Q: 設備列表還是顯示「載入中...」
**A:** 檢查控制台日誌:
1. 是否有權限請求被拒絕？
2. 是否有 DOM 元素不存在的錯誤？
3. 嘗試刷新頁面

### Q: 觀眾端看不到視頻
**A:** 檢查:
```javascript
const streamVideo = document.getElementById('streamVideo');
console.log('Container classes:', streamVideo.className);
// 應該包含 'live'

const video = document.getElementById('remoteVideo');
console.log('Video src:', !!video.srcObject);
console.log('Video display:', window.getComputedStyle(video).display);
// display 應該是 'block'
```

### Q: 特效看不到
**A:** 確認:
1. 視頻是否可見？（測試2必須通過）
2. 控制台是否有 CSS 載入錯誤？
3. 嘗試切換到其他特效再切回來

---

## 成功標準

所有以下條件都滿足時，測試通過: ✅

1. **設備載入**: 主播端三個下拉選單都正確顯示設備
2. **視頻顯示**: 觀眾端可以看到主播的實時視頻
3. **邊框特效**: 彩虹邊框和霓虹邊框都正確顯示
4. **濾鏡特效**: 彩虹濾鏡正確應用並有動畫效果
5. **無錯誤**: 控制台沒有紅色錯誤訊息
6. **性能**: 特效切換流暢，沒有明顯延遲

---

## 測試完成後

如果所有測試通過，你可以:
1. ✅ 關閉開發者工具，正常使用
2. ✅ 測試其他特效是否也正常工作
3. ✅ 測試多個觀眾同時觀看

如果有測試失敗:
1. ❌ 記錄控制台的完整錯誤訊息
2. ❌ 截圖顯示問題
3. ❌ 查看詳細的修復報告文檔進行排查
