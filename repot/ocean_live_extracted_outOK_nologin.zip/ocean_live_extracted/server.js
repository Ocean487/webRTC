const WebSocket = require('ws');
const http = require('http');
const https = require('https');
const fs = require('fs');
const express = require('express');
const session = require('express-session');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const Database = require('./database');

// 全局工具函數：安全的JSON發送
function sendJSON(ws, obj) {
    try {
        if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify(obj));
            return true;
        }
        return false;
    } catch (err) {
        console.error('sendJSON error', err);
        return false;
    }
}

// 創建 Express 應用
const app = express();

// 初始化資料庫
const db = new Database();

// 中間件設置
app.use(express.static(path.join(__dirname)));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 設置 session 中間件
app.use(session({
    secret: 'vibelo-secret-key-2025',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false, // 允許HTTP和HTTPS
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000 // 24 小時
    }
}));

// 簡化的直播狀態管理
let isStreaming = false;
let broadcaster = null;
let viewers = new Map();
let viewerCount = 0;

// 創建HTTP服務器（用於IIS轉發）
const httpServer = http.createServer(app);
httpServer.setMaxListeners(20);

// 創建HTTPS服務器（用於直接訪問）
let httpsServer = null;
let isHttps = false;

try {
    // 嘗試讀取SSL證書
    const possiblePaths = [
        { key: 'private-key.pem', cert: 'certificate.pem' },
        { key: 'key.pem', cert: 'cert.pem' },
        { key: 'ssl/private-key.pem', cert: 'ssl/certificate.pem' },
        { key: 'certs/private-key.pem', cert: 'certs/certificate.pem' },
        { key: 'server.key', cert: 'server.crt' }
    ];
    
    let found = false;
    for (const pathPair of possiblePaths) {
        try {
            const keyFullPath = path.join(__dirname, pathPair.key);
            const certFullPath = path.join(__dirname, pathPair.cert);
            
            if (fs.existsSync(keyFullPath) && fs.existsSync(certFullPath)) {
                const options = {
                    key: fs.readFileSync(keyFullPath),
                    cert: fs.readFileSync(certFullPath)
                };
                httpsServer = https.createServer(options, app);
                httpsServer.setMaxListeners(20);
                isHttps = true;
                found = true;
                console.log(`🔍 找到SSL證書: ${pathPair.key}, ${pathPair.cert}`);
                break;
            }
        } catch (e) {
            // 繼續嘗試下一個路徑
        }
    }
    
    if (!found) {
        console.log('⚠️  未找到SSL證書，僅啟用HTTP服務器');
    }
} catch (error) {
    console.log('⚠️  SSL證書載入失敗，僅啟用HTTP服務器');
    console.log('   錯誤詳情:', error.message);
}

// 創建 WebSocket 服務器（使用HTTPS服務器，如果可用）
const wsServer = isHttps ? httpsServer : httpServer;
const wss = new WebSocket.Server({ server: wsServer });
wss.setMaxListeners(20);

// WebSocket 連接處理
wss.on('connection', function connection(ws, req) {
    console.log('新的 WebSocket 連接');
    
    ws.on('message', function message(data) {
        try {
            const message = JSON.parse(data);
            console.log('收到訊息:', message.type);
            
            // 簡單的訊息處理
            switch (message.type) {
                case 'broadcaster_join':
                    broadcaster = ws;
                    console.log('主播已加入');
                    sendJSON(ws, { type: 'ack', event: 'broadcaster_join', ok: true });
                    break;
                    
                case 'viewer_join':
                    viewers.set(message.viewerId || Date.now(), ws);
                    viewerCount = viewers.size;
                    console.log('觀眾已加入，當前觀眾數:', viewerCount);
                    sendJSON(ws, { type: 'ack', event: 'viewer_join', ok: true });
                    break;
                    
                case 'heartbeat':
                    sendJSON(ws, { type: 'heartbeat_ack', timestamp: new Date().toISOString() });
                    break;
                    
                default:
                    console.log('未知訊息類型:', message.type);
            }
        } catch (err) {
            console.error('處理訊息時發生錯誤:', err);
        }
    });
    
    ws.on('close', function close() {
        console.log('WebSocket 連接關閉');
        // 清理連接
        if (broadcaster === ws) {
            broadcaster = null;
            isStreaming = false;
        }
        
        // 從觀眾列表中移除
        for (const [viewerId, viewerWs] of viewers.entries()) {
            if (viewerWs === ws) {
                viewers.delete(viewerId);
                viewerCount = viewers.size;
                break;
            }
        }
    });
    
    ws.on('error', function error(err) {
        console.error('WebSocket 錯誤:', err);
    });
});

// 啟動服務器
const HTTP_PORT = process.env.HTTP_PORT || 3000;
const HTTPS_PORT = process.env.HTTPS_PORT || 3000;

// 啟動HTTP服務器（用於IIS轉發）
httpServer.on('error', (error) => {
    console.error('❌ HTTP服務器錯誤:', error);
    if (error.code === 'EADDRINUSE') {
        console.error(`❌ 端口 ${HTTP_PORT} 已被占用`);
        process.exit(1);
    }
});

httpServer.listen(HTTP_PORT, () => {
    console.log('🚀 VibeLo 直播平台伺服器已啟動');
    console.log(`📡 HTTP 伺服器運行在: http://localhost:${HTTP_PORT} (用於IIS轉發)`);
    
    if (isHttps && httpsServer) {
        // 啟動HTTPS服務器（用於直接訪問）
        httpsServer.on('error', (error) => {
            console.error('❌ HTTPS服務器錯誤:', error);
            if (error.code === 'EADDRINUSE') {
                console.error(`❌ HTTPS端口 ${HTTPS_PORT} 已被占用`);
            }
        });
        
        httpsServer.listen(HTTPS_PORT, () => {
            console.log(`🔒 HTTPS 伺服器運行在: https://localhost:${HTTPS_PORT} (用於直接訪問)`);
            console.log(`🔌 WebSocket 伺服器運行在: wss://localhost:${HTTPS_PORT}`);
            console.log('📱 移動端支援: 完全支援');
            console.log(`📺 主播端: https://localhost:${HTTPS_PORT}/livestream_platform.html`);
            console.log(`👥 觀眾端: https://localhost:${HTTPS_PORT}/viewer.html`);
            console.log(`🌍 外網訪問: https://vibelo.l0sscat.com:8443`);
        });
    } else {
        console.log(`🔌 WebSocket 伺服器運行在: ws://localhost:${HTTP_PORT}`);
        console.log('📱 移動端支援: 有限制（需要HTTPS）');
        console.log(`📺 主播端: http://localhost:${HTTP_PORT}/livestream_platform.html`);
        console.log(`👥 觀眾端: http://localhost:${HTTP_PORT}/viewer.html`);
    }
    
    console.log(`📄 測試帳號列表: http://localhost:${HTTP_PORT}/test-accounts.html`);
    console.log('💾 使用 SQLite 資料庫進行用戶管理');
    
    // 確保服務器保持運行
    console.log('🔄 服務器正在運行中...');
    console.log('⏹️  按 Ctrl+C 停止服務器');
});

// 防止進程意外退出
process.stdin.resume();

// 監聽關閉信號
process.on('SIGINT', () => {
    console.log('\n🛑 正在關閉伺服器...');
    
    // 關閉所有WebSocket連接
    if (broadcaster) {
        broadcaster.close();
    }
    
    viewers.forEach((ws) => {
        if (ws && ws.readyState === WebSocket.OPEN) {
            ws.close();
        }
    });
    
    // 關閉服務器
    httpServer.close(() => {
        console.log('✅ HTTP伺服器已關閉');
        
        if (httpsServer) {
            httpsServer.close(() => {
                console.log('✅ HTTPS伺服器已關閉');
                process.exit(0);
            });
        } else {
            process.exit(0);
        }
    });
    
    // 如果5秒內沒有正常關閉，強制退出
    setTimeout(() => {
        console.log('⚠️  強制關閉伺服器');
        process.exit(1);
    }, 5000);
});

// 監聽未捕獲的異常
process.on('uncaughtException', (error) => {
    console.error('❌ 未捕獲的異常:', error);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ 未處理的Promise拒絕:', reason);
});
