// WebRTC 配置
const configuration = {
    iceServers: [
        { urls: 'stun:stun.l.google.com:19302' }
    ]
};

// 全局變數
let localStream = null;
let peerConnections = new Map();
let isStreaming = false;
let streamStartTime = null;

// 初始化
document.addEventListener('DOMContentLoaded', async () => {
    if (!checkAuth()) return;
    
    initializeStream();
    setupChatSystem();
    updateUIForRole();
});

// 初始化直播
async function initializeStream() {
    const urlParams = new URLSearchParams(window.location.search);
    const streamId = urlParams.get('id');
    
    if (streamId) {
        // 觀眾模式
        document.getElementById('streamControls').style.display = 'none';
        await joinStream(streamId);
    } else {
        // 主播模式
        document.getElementById('startStreamButton').addEventListener('click', toggleStream);
    }
}

// 開始/停止直播
async function toggleStream() {
    if (!isStreaming) {
        try {
            localStream = await navigator.mediaDevices.getUserMedia({
                video: true,
                audio: true
            });
            
            document.getElementById('streamVideo').srcObject = localStream;
            document.getElementById('startStreamButton').textContent = '結束直播';
            
            isStreaming = true;
            streamStartTime = Date.now();
            startStreamingSession();
            
        } catch (error) {
            console.error('無法訪問攝像頭或麥克風:', error);
            alert('無法訪問攝像頭或麥克風，請確認權限設置');
        }
    } else {
        stopStreaming();
    }
}

// 停止直播
function stopStreaming() {
    if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
        document.getElementById('streamVideo').srcObject = null;
    }
    
    isStreaming = false;
    document.getElementById('startStreamButton').textContent = '開始直播';
    
    // 清理連接
    peerConnections.forEach(connection => connection.close());
    peerConnections.clear();
}

// 加入直播
async function joinStream(streamId) {
    // TODO: 實現觀眾加入直播的邏輯
    console.log('加入直播:', streamId);
}

// 聊天系統
function setupChatSystem() {
    const chatInput = document.getElementById('chatInput');
    const chatMessages = document.getElementById('chatMessages');
    
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && chatInput.value.trim()) {
            sendMessage();
        }
    });
}

// 發送聊天訊息
function sendMessage() {
    const chatInput = document.getElementById('chatInput');
    const message = chatInput.value.trim();
    
    if (!message) return;
    
    // 添加訊息到聊天室
    addMessageToChat(currentUser.username, message);
    
    // 清空輸入框
    chatInput.value = '';
}

// 添加訊息到聊天室
function addMessageToChat(username, message) {
    const chatMessages = document.getElementById('chatMessages');
    const messageElement = document.createElement('div');
    messageElement.className = 'chat-message';
    messageElement.innerHTML = `
        <span class="username">${username}:</span>
        <span class="message">${message}</span>
    `;
    chatMessages.appendChild(messageElement);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// 根據角色更新界面
function updateUIForRole() {
    const urlParams = new URLSearchParams(window.location.search);
    const streamId = urlParams.get('id');
    
    const streamControls = document.getElementById('streamControls');
    const streamSettings = document.querySelector('.stream-settings');
    
    if (streamId) {
        // 觀眾界面
        streamControls.style.display = 'none';
        streamSettings.style.display = 'none';
    } else {
        // 主播界面
        streamControls.style.display = 'flex';
        streamSettings.style.display = 'flex';
    }
}

// 更新觀眾數量
function updateViewerCount(count) {
    document.getElementById('viewerCount').textContent = count;
}

// 更新直播時長
setInterval(() => {
    if (isStreaming && streamStartTime) {
        const duration = Math.floor((Date.now() - streamStartTime) / 1000);
        const hours = Math.floor(duration / 3600);
        const minutes = Math.floor((duration % 3600) / 60);
        const seconds = duration % 60;
        
        document.getElementById('streamDuration').textContent = 
            `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
}, 1000);
