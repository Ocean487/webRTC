// 移動菜單狀態
let isMenuOpen = false;

// 切換移動菜單
function toggleMenu() {
    const navLinks = document.querySelector('.nav-links');
    const menuButton = document.querySelector('.menu-toggle');
    
    isMenuOpen = !isMenuOpen;
    
    if (isMenuOpen) {
        navLinks.classList.add('active');
        menuButton.innerHTML = '<i class="fas fa-times"></i>';
    } else {
        navLinks.classList.remove('active');
        menuButton.innerHTML = '<i class="fas fa-bars"></i>';
    }
}

// 切換密碼可見性
function togglePassword(inputId = 'password', iconSelector = null) {
    const input = document.getElementById(inputId);
    const icon = iconSelector ? 
        document.querySelector(iconSelector) : 
        document.querySelector(`#${inputId} ~ .toggle-password i`);
    
    if (input && icon) {
        if (input.type === 'password') {
            input.type = 'text';
            icon.className = 'fas fa-eye-slash';
        } else {
            input.type = 'password';
            icon.className = 'fas fa-eye';
        }
    }
}

// 修復連結路徑
function fixLinks() {
    document.querySelectorAll('a[href^="/"]').forEach(link => {
        const href = link.getAttribute('href');
        if (href.startsWith('/')) {
            const newHref = href.substring(1);
            // 確保不會自動跳轉到preview.html
            if (newHref !== 'preview.html') {
                link.setAttribute('href', newHref);
            }
        }
    });
}

// 頁面載入時初始化
document.addEventListener('DOMContentLoaded', () => {
    // 修復連結
    fixLinks();
    
    // 設置當前頁面的活動狀態
    const currentPath = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPath) {
            link.classList.add('active');
        }
    });

    // 監聽所有帶有 hash 的連結
    document.querySelectorAll('a[href*="#"]').forEach(link => {
        link.addEventListener('click', (e) => {
            const href = link.getAttribute('href');
            if (href.includes('#')) {
                const [path, hash] = href.split('#');
                const currentPage = window.location.pathname.split('/').pop();
                
                // 如果是當前頁面的錨點，阻止默認行為並平滑滾動
                if (!path || path === currentPage) {
                    e.preventDefault();
                    const element = document.getElementById(hash);
                    if (element) {
                        element.scrollIntoView({ behavior: 'smooth' });
                        // 如果移動菜單是開啟的，關閉它
                        if (isMenuOpen) toggleMenu();
                    }
                }
            }
        });
    });
});

    goToProfile(username) {
        if (this.checkPermission()) {
            window.location.href = `${this.pages.profile}?user=${username}`;
        }
    },

    goToSettings() {
        if (this.checkPermission()) {
            window.location.href = this.pages.settings;
        }
    },

    logout() {
        localStorage.removeItem('currentUser');
        sessionStorage.clear();
        this.goToPreview();
    },

    // 返回按鈕處理
    handleBack() {
        const previousPage = sessionStorage.getItem('previousPage');
        if (previousPage) {
            window.location.href = previousPage;
        } else {
            this.goToHome();
        }
    },

    // 初始化導航
    init() {
        // 保存當前頁面路徑
        const currentPath = window.location.pathname;
        
        // 排除登入和預覽頁面
        if (!currentPath.includes('login.html') && !currentPath.includes('preview.html')) {
            sessionStorage.setItem('previousPage', currentPath);
        }

        // 設置導航欄用戶信息
        this.updateUserNav();
    },

    // 更新導航欄用戶信息
    updateUserNav() {
        const currentUser = JSON.parse(localStorage.getItem('currentUser'));
        const userMenu = document.getElementById('userMenu');
        
        if (userMenu && currentUser) {
            const avatar = userMenu.querySelector('.avatar');
            if (avatar) {
                avatar.src = currentUser.avatar || 'default-avatar.png';
                avatar.alt = currentUser.username;
            }
        }
    }
};

// 在頁面加載時初始化導航
document.addEventListener('DOMContentLoaded', () => {
    navigation.init();
});
