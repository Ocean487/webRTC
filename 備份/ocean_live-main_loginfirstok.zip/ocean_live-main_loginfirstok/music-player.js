// 音頻相關變數
let audioContext;
let musicAudioNode;
let streamDestination;
let youtubePlayer;
let isMuted = false;
let currentVolume = 100; // 預設最大音量

// 初始化事件監聽
document.addEventListener('DOMContentLoaded', () => {
    // 初始化 YouTube API
    initYouTubeAPI();
    
    // 初始化音量控制
    const volumeSlider = document.getElementById('volumeSlider');
    if (volumeSlider) {
        volumeSlider.value = currentVolume;
        volumeSlider.addEventListener('input', (e) => {
            setVolume(parseInt(e.target.value));
        });
    }
    
    // 初始化輸入框事件
    const urlInput = document.getElementById('youtube-url');
    if (urlInput) {
        urlInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                loadYouTubeVideo();
            }
        });
    }
});

// 初始化音頻環境
function initAudioContext() {
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
    streamDestination = audioContext.createMediaStreamDestination();
}

// 初始化 YouTube API
function initYouTubeAPI() {
    const tag = document.createElement('script');
    tag.src = "https://www.youtube.com/iframe_api";
    const firstScriptTag = document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
    
    // 初始化音頻環境
    initAudioContext();
}

// YouTube API 準備就緒時調用
function onYouTubeIframeAPIReady() {
    youtubePlayer = new YT.Player('youtube-embed', {
        height: '180',
        width: '100%',
        playerVars: {
            'playsinline': 1,
            'controls': 1,
            'autoplay': 1,
            'mute': 0
        },
        events: {
            'onReady': onPlayerReady,
            'onStateChange': onPlayerStateChange
        }
    });
}

function onPlayerReady(event) {
    console.log('YouTube播放器準備就緒');
    
    // 設置初始音量
    youtubePlayer.setVolume(currentVolume);
    youtubePlayer.unMute();
    
    // 連接音頻流
    if (audioContext && streamDestination) {
        const videoElement = event.target.getIframe();
        const source = audioContext.createMediaElementSource(videoElement);
        source.connect(streamDestination);
        source.connect(audioContext.destination); // 本地播放
    }
}

function onPlayerStateChange(event) {
    // 播放狀態改變時重新同步音頻流
    if (event.data === YT.PlayerState.PLAYING) {
        if (streamDestination && localStream) {
            // 通知直播系統音頻流已更新
            updateStreamAudio();
        }
    }
}

// 更新直播音頻流
function updateStreamAudio() {
    if (typeof startStream === 'function') {
        // 重新啟動流以更新音頻
        startStream().catch(console.error);
    }
}

// YouTube 搜尋功能
async function searchYouTube() {
    const query = document.getElementById('youtube-search').value;
    if (!query) {
        alert('請輸入搜尋關鍵字');
        return;
    }

    try {
        const response = await fetch(`https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(query)}&type=video&key=YOUR_API_KEY&maxResults=5`);
        const data = await response.json();
        
        const resultsContainer = document.getElementById('search-results');
        resultsContainer.innerHTML = '';
        
        data.items.forEach(item => {
            const resultDiv = document.createElement('div');
            resultDiv.className = 'search-result-item';
            resultDiv.onclick = () => loadVideo(item.id.videoId);
            
            resultDiv.innerHTML = `
                <img src="${item.snippet.thumbnails.default.url}" alt="${item.snippet.title}">
                <div class="search-result-info">
                    <div class="search-result-title">${item.snippet.title}</div>
                    <div class="search-result-channel">${item.snippet.channelTitle}</div>
                </div>
            `;
            
            resultsContainer.appendChild(resultDiv);
        });
    } catch (error) {
        console.error('搜尋失敗:', error);
        alert('搜尋失敗，請稍後再試');
    }
}

// 載入視頻
function loadVideo(videoId) {
    if (videoId) {
        youtubePlayer.loadVideoById({
            videoId: videoId,
            startSeconds: 0,
            suggestedQuality: 'default'
        });
        youtubePlayer.setVolume(currentVolume);
        youtubePlayer.unMute();
    }
}

// Enter 鍵搜尋
document.getElementById('youtube-search').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        searchYouTube();
    }
});

// 切換靜音
function toggleMute() {
    if (youtubePlayer) {
        isMuted = !isMuted;
        if (isMuted) {
            youtubePlayer.mute();
        } else {
            youtubePlayer.unMute();
            youtubePlayer.setVolume(currentVolume);
        }
        document.getElementById('muteButton').textContent = isMuted ? '🔇' : '🔊';
    }
}

// 設置音量
function setVolume(value) {
    currentVolume = value;
    if (youtubePlayer && !isMuted) {
        youtubePlayer.setVolume(currentVolume);
    }
}

// 初始化音樂播放器
document.addEventListener('DOMContentLoaded', function() {
    initYouTubeAPI();
    
    // 初始化音量控制
    const volumeSlider = document.getElementById('volumeSlider');
    volumeSlider.value = currentVolume;
    volumeSlider.addEventListener('input', function(e) {
        setVolume(parseInt(e.target.value));
    });
});
