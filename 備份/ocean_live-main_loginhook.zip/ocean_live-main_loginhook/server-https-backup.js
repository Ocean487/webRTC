const WebSocket = require('ws');
const http = require('http');
const express = require('express');
const session = require('express-session');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const Database = require('./database');

// 創建 Express 應用
const app = express();
const server = http.createServer(app);

// 初始化資料庫
const db = new Database();

// 中間件設置
app.use(express.static(path.join(__dirname)));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 設置 session 中間件
app.use(session({
    secret: 'vibelo-secret-key-2025',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false, // 在生產環境中應該設為 true (需要 HTTPS)
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000 // 24 小時
    }
}));

// 當前活躍用戶 (用於防止衝突)
const activeUsers = new Map(); // userId -> { sessionId, socketId, lastActivity }

// 創建 WebSocket 服務器
const wss = new WebSocket.Server({ server });

// 直播狀態
let isStreaming = false;
let broadcaster = null;
let viewers = new Map(); // viewerId -> WebSocket
let viewerCount = 0;

// WebSocket 連接處理
wss.on('connection', function connection(ws, req) {
    console.log('新的 WebSocket 連接');
    
    let clientType = null; // 'broadcaster' 或 'viewer'
    let clientId = null;
    
    ws.on('message', function message(data) {
        try {
            const message = JSON.parse(data);
            console.log('收到訊息:', message.type);
            
            switch (message.type) {
                case 'broadcaster_join':
                    handleBroadcasterJoin(ws, message);
                    clientType = 'broadcaster';
                    break;
                    
                case 'viewer_join':
                    handleViewerJoin(ws, message);
                    clientType = 'viewer';
                    clientId = message.viewerId;
                    break;
                    
                case 'stream_start':
                    handleStreamStart(message);
                    break;
                    
                case 'stream_end':
                    handleStreamEnd();
                    break;
                    
                case 'offer':
                    handleOffer(message);
                    break;
                    
                case 'answer':
                    handleAnswer(message);
                    break;
                    
                case 'ice_candidate':
                    handleIceCandidate(message);
                    break;
                    
                case 'chat_message':
                    handleChatMessage(message);
                    break;
                    
                case 'broadcaster_chat_message':
                    handleBroadcasterChatMessage(message);
                    break;
                    
                case 'heartbeat':
                    // 心跳包，不需要特別處理
                    break;
                    
                default:
                    console.log('未知訊息類型:', message.type);
            }
            
        } catch (error) {
            console.error('處理訊息時發生錯誤:', error);
        }
    });
    
    ws.on('close', function close() {
        console.log('WebSocket 連接關閉');
        
        if (clientType === 'broadcaster') {
            handleBroadcasterDisconnect();
        } else if (clientType === 'viewer' && clientId) {
            handleViewerDisconnect(clientId);
        }
    });
    
    ws.on('error', function error(err) {
        console.error('WebSocket 錯誤:', err);
    });
});

// 處理主播加入
function handleBroadcasterJoin(ws, message) {
    console.log('主播已加入');
    broadcaster = {
        ws: ws,
        id: message.broadcasterId || 'broadcaster_1',
        timestamp: Date.now()
    };
    
    // 發送確認訊息
    ws.send(JSON.stringify({
        type: 'broadcaster_joined',
        message: '主播已成功加入直播間'
    }));
}

// 處理觀眾加入
function handleViewerJoin(ws, message) {
    const viewerId = message.viewerId;
    console.log('觀眾加入:', viewerId);
    
    viewers.set(viewerId, ws);
    viewerCount++;
    
    // 發送確認訊息
    ws.send(JSON.stringify({
        type: 'viewer_joined',
        message: '觀眾已成功加入直播間',
        viewerId: viewerId
    }));
    
    // 如果主播正在直播，發送直播開始訊息
    if (isStreaming && broadcaster) {
        console.log('觀眾加入時主播正在直播，發送 stream_start');
        ws.send(JSON.stringify({
            type: 'stream_start',
            title: '直播中',
            message: '主播正在直播中'
        }));
        
        // 通知主播有新觀眾需要連接
        if (broadcaster.ws.readyState === WebSocket.OPEN) {
            console.log('通知主播有新觀眾需要連接:', viewerId);
            broadcaster.ws.send(JSON.stringify({
                type: 'viewer_join',
                viewerId: viewerId
            }));
        }
    } else {
        console.log('觀眾加入時主播未在直播');
    }
    
    // 更新所有觀眾的觀眾數量
    updateViewerCount();
}

// 處理直播開始
function handleStreamStart(message) {
    console.log('直播開始');
    isStreaming = true;
    
    // 通知所有觀眾直播已開始
    broadcastToViewers({
        type: 'stream_start',
        title: message.title || '直播中',
        message: '主播已開始直播'
    });
    
    // 通知主播有哪些觀眾需要連接
    if (broadcaster && broadcaster.ws.readyState === WebSocket.OPEN) {
        const viewerList = Array.from(viewers.keys());
        if (viewerList.length > 0) {
            broadcaster.ws.send(JSON.stringify({
                type: 'viewers_need_connection',
                viewers: viewerList,
                message: `有 ${viewerList.length} 個觀眾等待連接`
            }));
        }
    }
}

// 處理直播結束
function handleStreamEnd() {
    console.log('直播結束');
    isStreaming = false;
    
    // 通知所有觀眾直播已結束
    broadcastToViewers({
        type: 'stream_end',
        message: '直播已結束'
    });
}

// 處理 WebRTC Offer
function handleOffer(message) {
    console.log('處理 Offer from broadcaster to viewer:', message.viewerId);
    
    // 將 Offer 轉發給特定觀眾
    if (message.viewerId && viewers.has(message.viewerId)) {
        const viewerWs = viewers.get(message.viewerId);
        if (viewerWs.readyState === WebSocket.OPEN) {
            viewerWs.send(JSON.stringify({
                type: 'offer',
                offer: message.offer,
                broadcasterId: message.broadcasterId
            }));
        }
    }
}

// 處理 WebRTC Answer
function handleAnswer(message) {
    console.log('處理 Answer from:', message.viewerId);
    
    // 將 Answer 轉發給主播
    if (broadcaster && broadcaster.ws.readyState === WebSocket.OPEN) {
        broadcaster.ws.send(JSON.stringify({
            type: 'answer',
            answer: message.answer,
            viewerId: message.viewerId
        }));
    }
}

// 處理 ICE 候選
function handleIceCandidate(message) {
    console.log('處理 ICE 候選:', message.broadcasterId ? 'from broadcaster' : 'from viewer');
    
    if (message.broadcasterId) {
        // 來自主播的 ICE 候選，轉發給特定觀眾
        if (message.viewerId && viewers.has(message.viewerId)) {
            const viewerWs = viewers.get(message.viewerId);
            if (viewerWs.readyState === WebSocket.OPEN) {
                viewerWs.send(JSON.stringify({
                    type: 'ice_candidate',
                    candidate: message.candidate,
                    broadcasterId: message.broadcasterId
                }));
            }
        }
    } else if (message.viewerId) {
        // 來自觀眾的 ICE 候選，轉發給主播
        if (broadcaster && broadcaster.ws.readyState === WebSocket.OPEN) {
            broadcaster.ws.send(JSON.stringify({
                type: 'ice_candidate',
                candidate: message.candidate,
                viewerId: message.viewerId
            }));
        }
    }
}

// 處理聊天訊息
function handleChatMessage(message) {
    console.log('聊天訊息:', message.message);
    
    // 廣播聊天訊息給所有連接的客戶端
    const chatMessage = {
        type: 'chat_message',
        username: message.username || message.viewerId,
        message: message.message,
        timestamp: message.timestamp,
        viewerId: message.viewerId
    };
    
    // 發送給所有觀眾
    broadcastToViewers(chatMessage);
    
    // 發送給主播
    if (broadcaster && broadcaster.ws.readyState === WebSocket.OPEN) {
        broadcaster.ws.send(JSON.stringify(chatMessage));
    }
}

// 處理主播聊天訊息
function handleBroadcasterChatMessage(message) {
    console.log('主播聊天訊息:', message.message);
    
    // 廣播主播訊息給所有觀眾
    const chatMessage = {
        type: 'chat_message',
        username: '主播',
        message: message.message,
        timestamp: message.timestamp,
        broadcasterId: message.broadcasterId
    };
    
    // 發送給所有觀眾
    broadcastToViewers(chatMessage);
    
    console.log('已廣播主播訊息給', viewerCount, '個觀眾');
}

// 處理主播斷線
function handleBroadcasterDisconnect() {
    console.log('主播斷線');
    broadcaster = null;
    isStreaming = false;
    
    // 通知所有觀眾主播已斷線
    broadcastToViewers({
        type: 'stream_end',
        message: '主播已斷線，直播結束'
    });
}

// 處理觀眾斷線
function handleViewerDisconnect(viewerId) {
    console.log('觀眾斷線:', viewerId);
    
    if (viewers.has(viewerId)) {
        viewers.delete(viewerId);
        viewerCount--;
        updateViewerCount();
    }
}

// 廣播訊息給所有觀眾
function broadcastToViewers(message) {
    viewers.forEach((viewer, viewerId) => {
        if (viewer.readyState === WebSocket.OPEN) {
            try {
                viewer.send(JSON.stringify(message));
            } catch (error) {
                console.error('發送訊息給觀眾失敗:', error);
                // 移除斷線的觀眾
                viewers.delete(viewerId);
                viewerCount--;
            }
        }
    });
}

// 更新觀眾數量
function updateViewerCount() {
    const countMessage = {
        type: 'viewer_count_update',
        count: viewerCount
    };
    
    // 更新所有觀眾的數量顯示
    broadcastToViewers(countMessage);
    
    // 更新主播的數量顯示
    if (broadcaster && broadcaster.ws.readyState === WebSocket.OPEN) {
        broadcaster.ws.send(JSON.stringify(countMessage));
    }
}

// 定期清理斷線的連接
setInterval(() => {
    // 清理斷線的觀眾
    viewers.forEach((viewer, viewerId) => {
        if (viewer.readyState !== WebSocket.OPEN) {
            console.log('清理斷線觀眾:', viewerId);
            viewers.delete(viewerId);
            viewerCount--;
        }
    });
    
    // 清理斷線的主播
    if (broadcaster && broadcaster.ws.readyState !== WebSocket.OPEN) {
        console.log('清理斷線主播');
        broadcaster = null;
        isStreaming = false;
    }
    
    // 更新觀眾數量
    if (viewerCount !== viewers.size) {
        viewerCount = viewers.size;
        updateViewerCount();
    }
}, 30000); // 每30秒檢查一次

// === 登入和註冊路由 ===

// 認證中間件
function requireAuth(req, res, next) {
    if (req.session.userId) {
        next();
    } else {
        res.status(401).json({
            success: false,
            message: '請先登入'
        });
    }
}

// 檢查用戶是否已在其他地方登入
function checkUserConflict(userId, sessionId) {
    const activeUser = activeUsers.get(userId);
    if (activeUser && activeUser.sessionId !== sessionId) {
        return true; // 有衝突
    }
    return false; // 無衝突
}

// 登入處理
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    
    console.log('🔐 登入嘗試:', { email, password: '*'.repeat(password.length) });
    
    try {
        // 使用資料庫驗證用戶
        const user = await db.authenticateUser(email, password);
        
        // 檢查用戶是否已在其他地方登入
        if (checkUserConflict(user.id, req.sessionID)) {
            // 踢掉之前的會話
            const previousUser = activeUsers.get(user.id);
            if (previousUser) {
                await db.deleteSession(previousUser.sessionId);
            }
        }
        
        // 設置會話
        req.session.userId = user.id;
        req.session.user = user;
        
        // 記錄活躍用戶
        activeUsers.set(user.id, {
            sessionId: req.sessionID,
            lastActivity: Date.now()
        });
        
        // 創建資料庫會話記錄
        const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24小時後過期
        await db.createSession(req.sessionID, user.id, expiresAt, req.ip, req.get('User-Agent'));
        
        console.log('✅ 登入成功:', user.displayName);
        res.json({
            success: true,
            message: '登入成功！',
            user: user,
            redirectUrl: '/index.html'
        });
        
    } catch (error) {
        console.log('❌ 登入失敗:', error.message);
        res.status(401).json({
            success: false,
            message: error.message
        });
    }
});

// 註冊處理
app.post('/register', async (req, res) => {
    const { username, email, password, confirmPassword } = req.body;
    
    console.log('📝 註冊嘗試:', { username, email });
    
    // 檢查密碼是否一致
    if (password !== confirmPassword) {
        return res.status(400).json({
            success: false,
            message: '兩次輸入的密碼不一致'
        });
    }
    
    // 檢查密碼強度
    if (password.length < 6) {
        return res.status(400).json({
            success: false,
            message: '密碼至少需要6個字符'
        });
    }
    
    try {
        // 使用資料庫創建用戶
        const newUser = await db.createUser(username, email, password, username);
        
        console.log('✅ 註冊成功:', username);
        res.json({
            success: true,
            message: '註冊成功！請使用新帳號登入',
            redirectUrl: '/login.html'
        });
        
    } catch (error) {
        console.log('❌ 註冊失敗:', error.message);
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
});

// 登出處理
app.post('/logout', async (req, res) => {
    try {
        if (req.session.userId) {
            // 從活躍用戶列表中移除
            activeUsers.delete(req.session.userId);
            
            // 刪除資料庫中的會話
            await db.deleteSession(req.sessionID);
            
            // 銷毀會話
            req.session.destroy((err) => {
                if (err) {
                    console.error('銷毀會話失敗:', err);
                }
            });
            
            console.log('✅ 用戶已登出');
        }
        
        res.json({
            success: true,
            message: '已成功登出'
        });
        
    } catch (error) {
        console.error('登出失敗:', error);
        res.status(500).json({
            success: false,
            message: '登出失敗'
        });
    }
});

// 獲取當前用戶資訊
app.get('/api/user', requireAuth, async (req, res) => {
    try {
        const user = await db.getUserById(req.session.userId);
        res.json({
            success: true,
            user: user
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: '獲取用戶資訊失敗'
        });
    }
});

// 檢查會話狀態
app.get('/api/session/check', async (req, res) => {
    try {
        if (!req.session.userId) {
            return res.json({
                authenticated: false
            });
        }
        
        // 檢查是否有會話衝突
        if (checkUserConflict(req.session.userId, req.sessionID)) {
            // 強制登出
            req.session.destroy();
            return res.json({
                authenticated: false,
                conflict: true,
                message: '您的帳號已在其他地方登入'
            });
        }
        
        // 更新最後活動時間
        const activeUser = activeUsers.get(req.session.userId);
        if (activeUser) {
            activeUser.lastActivity = Date.now();
        }
        
        const user = await db.getUserById(req.session.userId);
        res.json({
            authenticated: true,
            user: user
        });
        
    } catch (error) {
        res.json({
            authenticated: false
        });
    }
});

// 獲取活躍用戶數量（管理員功能）
app.get('/api/admin/active-users', requireAuth, (req, res) => {
    // 這裡可以添加管理員權限檢查
    res.json({
        activeUsersCount: activeUsers.size,
        activeUsers: Array.from(activeUsers.entries()).map(([userId, info]) => ({
            userId,
            sessionId: info.sessionId,
            lastActivity: new Date(info.lastActivity)
        }))
    });
});

// 忘記密碼處理
app.post('/forgot-password', async (req, res) => {
    const { email } = req.body;
    
    console.log('🔑 忘記密碼請求:', email);
    
    try {
        // 檢查用戶是否存在（不透露密碼）
        const user = await db.getUserByEmail(email);
        
        console.log('✅ 找到用戶，模擬發送重設郵件');
        res.json({
            success: true,
            message: '如果該郵箱存在於我們的系統中，重設密碼連結已發送到您的電子郵件'
        });
    } catch (error) {
        // 為了安全，即使用戶不存在也返回成功訊息
        res.json({
            success: true,
            message: '如果該郵箱存在於我們的系統中，重設密碼連結已發送到您的電子郵件'
        });
    }
});

// 獲取測試帳號列表（開發用）
app.get('/api/test-accounts', async (req, res) => {
    try {
        // 只在開發環境顯示測試帳號
        const accounts = [
            {
                username: 'testuser1',
                email: 'test1@vibelo.com', 
                password: '123456',
                displayName: '測試用戶一號'
            },
            {
                username: 'demouser',
                email: 'demo@vibelo.com',
                password: 'demo123', 
                displayName: '演示用戶'
            },
            {
                username: 'admin',
                email: 'admin@vibelo.com',
                password: 'admin888',
                displayName: '管理員'
            }
        ];
        
        res.json({
            success: true,
            accounts: accounts,
            message: '這些是預設的測試帳號'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: '無法獲取測試帳號'
        });
    }
});

// 定期清理過期會話和非活躍用戶
setInterval(async () => {
    try {
        // 清理資料庫中的過期會話
        await db.cleanupExpiredSessions();
        
        // 清理長時間非活躍的用戶
        const now = Date.now();
        const inactiveThreshold = 30 * 60 * 1000; // 30分鐘
        
        for (const [userId, userInfo] of activeUsers.entries()) {
            if (now - userInfo.lastActivity > inactiveThreshold) {
                console.log(`清理非活躍用戶: ${userId}`);
                activeUsers.delete(userId);
                await db.deleteSession(userInfo.sessionId);
            }
        }
        
        console.log(`✅ 會話清理完成，當前活躍用戶: ${activeUsers.size}`);
    } catch (error) {
        console.error('清理會話時發生錯誤:', error);
    }
}, 10 * 60 * 1000); // 每10分鐘執行一次

// 伺服器優雅關閉處理
process.on('SIGINT', async () => {
    console.log('\n🛑 正在關閉伺服器...');
    
    try {
        // 關閉資料庫連接
        db.close();
        
        // 關閉 WebSocket 伺服器
        wss.close();
        
        // 關閉 HTTP 伺服器
        server.close(() => {
            console.log('✅ 伺服器已安全關閉');
            process.exit(0);
        });
    } catch (error) {
        console.error('關閉伺服器時發生錯誤:', error);
        process.exit(1);
    }
});

// 啟動伺服器
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log('🚀 VibeLo 直播平台伺服器已啟動');
    console.log(`📡 HTTP 伺服器運行在: http://localhost:${PORT}`);
    console.log(`🔌 WebSocket 伺服器運行在: ws://localhost:${PORT}`);
    console.log('📄 測試帳號列表: http://localhost:' + PORT + '/test-accounts.html');
    console.log('💾 使用 SQLite 資料庫進行用戶管理');
});
